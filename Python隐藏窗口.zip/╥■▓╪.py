import win32con  # 定义

import win32gui  # 界面

import time  # 时间

jy= win32gui.FindWindow("Afx:01A80000:20b:00000000:00000000:01790ACB","屏幕广播")

time.sleep(10)

win32gui.ShowWindow(jy, win32con.SW_HIDE)  # 设置隐藏
